
package clase08;


public class Clase08 {


    public static void main(String[] args) {
        
        /*
        Convenciones de escritura
        camelCase -> estoEsUnaFraseEnCamelCase (tambi�n se la conoce como 
        lower camel case) => variables, m�todos y atributos
        PascalCase -> EstoEsUnaFraseEnPascalCase (tambi�n se la conoce como
        upper camel case) => clases e interfaces
        snake_case -> esto_es_una_frase_en_snake_case 
        */       
        
        System.out.println("Clase String");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //m�todos para comparar
        //al comparar con el operador == va a comparar que sean el mismo
        //objeto en memoria
        System.out.println(texto2 == "hola"); //false
        
        //hay otra oportunidad en la que la comparaci�n podr�a darnos true
        System.out.println(texto3 == "hola"); //true
        /*
        esto pasa porque se da un comportamiento especial denominado 
        "intering", lo que sucede es que las cadenas creadas con comillas
        dobles se almacenan en un pool de cadenas internas para ahorrar
        memoria, es decir, que de manera interna estar�an ocupando el 
        mismo espacio en memoria, por eso las considera iguales.
        */
        //comparar Strings con == no brinda un comportamiento garantizado
        
        //para comparar cadenas de caracteres teniendo en cuenta 
        //su contenido, se utilizan los m�todos
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase ignora las min�sculas y may�sculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        //.contains()
        //devuelve un booleano si contiene la subcadena que pasamos como par�metro
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        
        
        //.length()
        //devuelve la longitud del vector, es decir, cu�ntos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena est� vac�a, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        texto3 = "";
        System.out.println(texto3.isEmpty()); //true
        
        
        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena est� en blanco o consiste �nicamente de espacios
        //en blanco. Como por ejemplo, si solo tiene espacios, o tabulaciones
        //y/o saltos de l�nea
        String texto4 = "    ";
        System.out.println(texto4.isEmpty());  //false
        //toma los caracteres de espacio como contenido. La longitud es de 4
        System.out.println(texto4.isBlank()); //true
        
        //.charAt()
        //devuelve el caracter del �ndice que pasamos como par�metro
        System.out.println(texto1.charAt(3));
        System.out.println(texto2.charAt(3));
//        System.out.println(texto2.charAt(4)); error, no existe el �ndice 4 para una longitud de 4
        
        //.indexOf()
        //devuelve el �ndice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto"));
        //devuelve -1 porque la T est� en may�scula en texto1
        System.out.println(texto1.indexOf("Texto")); //10

        
        //.trim()
        //quita los espacios de adelante y de atr�s
        System.out.println("   buenas noches   ");
        System.out.println("   buenas noches   ".trim());
        
        //.startsWith() .endsWith()
        //devuelve un booleano si la cadena comienza o finaliza con la subcadena
        //pasada como par�metro
        System.out.println(texto1.startsWith("hola")); //false
        System.out.println(texto2.startsWith("hola")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true
        
        //m�todos replace()
        //remplazar un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplazar una cadena de caracteres por otra
        System.out.println(texto1.replace("texto", "caracteres"));
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplazar s�lo la primera vez que aparezca la subcadena
        texto4 = "manzana, manzana, naranja";
        System.out.println(texto4.replaceFirst("manzana","banana"));
        //reemplazar todas las veces que aparezca la subcadena
        System.out.println(texto4.replaceAll("manzana", "banana"));
        System.out.println(texto4.replace("manzana", "banana"));
        
        /*
        Si bien .replace() tambi�n reemplaza todas las veces que aparece la subcadena,
        el replaceAll() es m�s potente, nos permite buscar y reemplazar patrones de 
        expresiones regulares.
        Una expresi�n regular es una secuencia de caracteres que definen un patr�n de b�squeda.
        */
        
        String texto5 = "Mi n�mero de tel�fono es 011-8888-9999 y mi otro n�mero es 365-1010-2727";
        
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "[hide information]"));
        
        //el replaceAll() va a buscar y reemplazar todo el texto que coincida con el patr�n
        //de formato ###-####-####
        
        //.repeat() aparece a partir del JDK 11
        //repite la cadena la cantidad de veces que le indiquemos
        System.out.println(texto2.repeat(3));
        
        //.substring()
        //se utiliza para extraer una subcadena
        //si utilizamos un solo par�metro, nos devolver� una subcadena a apartir del �ndice dado
        System.out.println(texto1.substring(5));
        //si utilizamos dos par�metros le estamos indicando desde donde hasta donde queremos la subcadena
        System.out.println(texto1.substring(3,8));
        
        //anteriormente hemos visto .toLowerCase() y .toUpperCase()
        
        //caracteres de escape
        /*
        son secuencias especiales de caracteres que se utilizan en cadenas de texto y literales de
        caracteres para representar caracteres especiales o caracteres que no se pueden representar
        directamente.
        Los caracteres de escape comienzan con una barra invertida (\) seguida de un caracter que
        indica qu� tipo de escape se est� utilizando.
        */
        
        //algunos ejemplos:
        
        // \n salto de l�nea
        System.out.println("Hola\nMundo!");
        
        // \t tabulaci�n
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo!\'");
        
        // \\ contrabarra o barra invertida
        System.out.println("\\Hola Mundo!\\");
        
        System.out.println("\n************************************\n");
        
        System.out.println("** Clase System **");
        
        /*
        La clase System es un intermediario entre la m�quina virtual de Java y el entorno de 
        ejecuci�n en el que estamos ejecutando nuestro programa.
        Como la m�quina virtual de Java puede ejecutarse en m�ltiples plataformas, la clase
        System nos abstrae de la plataforma en la que se est� ejecutando.
        */
        
        //los atributos m�s cl�sicos son out, err, in
        //representan stream de entrada y salida
        //son atributos finales y est�ticos
        //out es un stream de salida sincronizado
        //err es un stream de salida desincronizado
        
        /*
        "stream" (flujo o corriente), es una secuencia de datos que se procesa o transmite de
        manera secuencial, en lugar de cargarse o procesarse en su totalidad antes de utilizarse.
        */
        
        System.out.println("Hola 1");
        System.out.println("Hola 2");
        System.out.println("Hola 3");
        System.out.println("Hola 4");
        System.out.println("Hola 5");
        System.out.println("Hola 6");
        System.out.println("Hola 7");
        System.out.println("Hola 8");
        System.out.println("Hola 9");
        System.out.println("Hola 10");
        System.out.println("Hola 11");
        System.out.println("Hola 12");
        System.out.println("Hola 13");
        System.out.println("Hola 14");
        System.out.println("Hola 15");
        System.out.println("Hola 16");
        System.out.println("Hola 17");
        System.out.println("Hola 18");
        System.out.println("Hola 19");
        System.out.println("Hola 20");
        
        System.err.println("OCURRI� UN ERROR !");
        
    }
    
}
