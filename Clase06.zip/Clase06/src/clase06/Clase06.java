/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase06;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("*** EJERCICIOS JAVA ***");
        
        System.out.println("** Ejercicio 1 **");
        /*
        Dados n1=5, n2=10 y n3=20. Informar:
        a) n1+n2
        b) n3-n1
        c) n1*n3
        d) n3/n2
        */
        
        int n1 = 5;
        int n2 = 10;
        int n3 = 20;
        
        System.out.println("a) la suma de n1+n2 es: " + (n1+n2));
//        System.out.println(n1 + n2);
        
        System.out.print("b) la resta de n3-n1 es: ");
        System.out.println(n3 - n1);
        
        System.out.print("c) la multiplicaci�n de n1*n3 es: ");
        System.out.println(n1 * n3);
        
        System.out.print("d) la divisi�n de n3/n2 es: ");
        System.out.println(n3 / n2);
        
        
        System.out.println("************************");
        System.out.println("** Ejercicio 2 **");
        
        /*
        Dados n1=10, n2=20 y n3=30. Informar :
        a) El total de la suma de todas las variables
        b) El promedio
        c) El resto entre n2 y n1
        */
        
        n1 = 10;
        n2 = 20;
        n3 = 30;
        
        int sumaTotal = n1 + n2 + n3;
        int promedio = sumaTotal / 3;
        int resto = n2 % n1;        
        
        
        System.out.println("El total de la suma de todas las variables es: " + sumaTotal);
        System.out.println("El promedio es: " + promedio);
        System.out.println("El resto entre n2 y n1 es: " + resto);
        
        
        System.out.println("************************");
        System.out.println("** Ejercicio 3 **");
        /*
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenaci�n entre las variables y los literales, mostrar en pantalla 
        la siguiente expresi�n:
        n1 es igual a 5, n2 es igual a 10 y n1 m�s n2 es igual a 15.
        */
        n1 = 5;
        n2 = 10;
        
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + n2 + 
                " y n1 m�s n2 es igual a " + (n1 + n2) + ".");
        
        
        System.out.println("************************");
        System.out.println("** Ejercicio 4 **");
        
        /*
        Haciendo uso de la constante IVA=21,calcular el precio con IVA de los siguientes 
        productos e informar:
        a) remera:$59.90
        b) pantal�n:$99.90
        c) campera:$149.90
        */
        
        
        
        
        
    }
    
}
