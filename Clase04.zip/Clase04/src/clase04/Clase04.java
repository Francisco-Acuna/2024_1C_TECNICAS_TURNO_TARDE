/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String palabra1 = "uesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";
        String palabra13 = "C";
        
        //A Cuesta le cuesta subir la cuesta. Y en medio de la cuesta,
        //va y se acuesta

        System.out.println(palabra4.toUpperCase() + " " + palabra13 + 
                palabra1 + " " + palabra6 + palabra5 + " " + 
                palabra13.toLowerCase() + palabra1 + " " + palabra2 +
                " " + palabra3 + " " + palabra13.toLowerCase() + 
                palabra1 + ". " + palabra11.toUpperCase() + " " +
                palabra5 + palabra9 + " " + palabra12 + " " +
                palabra10 + palabra5 + " " + palabra6 + palabra4 + " " +
                palabra13.toLowerCase() + palabra1 + " " + palabra7 +
                palabra4 + " " + palabra11 + " " + palabra8 + palabra5 +
                " " + palabra4 + palabra13.toLowerCase() + palabra1 + ".");
        
        
        //Constantes
        
        //las constantes son similares a las variables, pero la diferencia
        //es que su valor no puede cambiar
        final double PI = 3.14;
        //para declarar constantes debemos utilizar la palabra reservada "final"
        // por convenci�n el nombre de las constantes va en may�sculas
        //PI = 3.15; Error, no se puede cambiar el valor.
        
        // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        
        //Operadores
        
        //Operadores aritm�ticos
        /*
        + suma
        - resta
        * multiplicaci�n
        / divisi�n
        % m�dulo o resto de la divisi�n
        */
        
    }

}
