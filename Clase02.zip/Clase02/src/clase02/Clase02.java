/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase02;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola Mundo!!");

        //sout + tab
        System.out.println("Hello World!");

        //Comentarios
        //comentario en l�nea
        //si queremos seguir escribiendo debajo, tenemos que 
        //volver a escribir las dos //
        
        /*
        Esto es un bloque de comentarios
        Puedo escribir en varias l�neas
        No hay necesidad de agregar // en cada l�nea
         */
        
        /**
         * Esto es un comentario JavaDoc podemos escribir en varias l�neas se
         * utiliza para documentar (m�todos, clases, etc.)
         */
        
        
        System.out.println("Hola Francisco!");
        //esto es una sentencia 
        //una sentencia es una orden que le damos al programa
        //para que realice una tarea espec�fica
        //las sentencias finalizan con ;
        //el ; separa una sentencia de otra

        //impresi�n con salto de l�nea
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        System.out.println("5");

        //impresi�n sin salto de l�nea
        System.out.print("1");
        System.out.print("2");
        System.out.print("3");
        System.out.print("4");
        System.out.print("5");
        
        System.out.println("");
        
        //Variables
        
        /*
        Una variable es un nombre que se asocia con una
        porci�n de la memoria del ordenador, en donde se guarda
        el valor asignado a esa variable.
        Las variables deben declararse antes de usarlas.
        La declaraci�n es una sentencia en la que figura el
        tipo de dato y el nombre que le asignamos a la variable.
        */
        
        int a; //declaraci�n de variable con identificador y tipo de dato
        a = 2; //asignaci�n de valor a la variable
        int b = 3; //declaraci�n y asignaci�n de valor en una misma l�nea
        
        a = 4; //cambiamos el valor de la variable
//        a = "Hola"; ERROR, no se puede asignar otro tipo de dato
//                      como valor de la variable
//        char a; ERROR, la variable ya fue declarada como int,
//                      no la puedo volver a declarar

        //Una variable puede tener una �nica declaraci�n e innumerables valores
        //Los valores deben ser siempre del mismo tipo de dato.
        
        int c=12, d=32, e=41; //declaraci�n y asignaci�n m�ltiple en l�nea
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte de memoria y representa un n�mero entero
        //de entre -128 y 127
        byte f = 100;
        System.out.println(f); //imprime el valor de la variable
        
        //short - ocupa 2 bytes y representa un n�mero entero de
        //entre -32.768 y 32.767
        short g = -31589; //no usamos puntos para separar los miles
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un n�mero entero de
        //entre -2.147.483.648 y 2.147.483.647
        int h = 1235684978;
        System.out.println(h);

    }

}
