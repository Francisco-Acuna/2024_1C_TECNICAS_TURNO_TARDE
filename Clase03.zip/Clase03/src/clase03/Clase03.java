/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase03;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Tipos de datos primitivos (continuaci�n)
        
        //long - ocupa 8 bytes y representa un valor muy grande
        long i = 365987456321L; //debemos colocar una L al final del valor asignado
        //por convenci�n utilizamos una L may�scula
        System.out.println(i);
        
        //float - ocupa 4 bytes y tiene una precisi�n de 32 bits
        float j = 14.25f; //debemos colocar una f al final del valor asignado
        //el punto separa los decimales, no se utiliza la coma
        System.out.println(j);        
        
        //double - ocupa 8 bytes y tiene una precisi�n de 64 bits
        double k = 24.45; //no hace falta agregarle una letra al final del valor
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
        //boolean - ocupa 1 byte y almacena s�lo 2 valores (0 y 1)
        //que son representados por los valores true y false
        boolean l = true;
        boolean m = false;
        System.out.println(l);
        System.out.println(m);
        
        //char - ocupa 2 bytes, almacena un n�mero entero que representa
        //un caracter de la tabla unicode
        //unicode es un est�ndar de codificaci�n de caracteres a nivel mundial
        char n = 65; //se almacena como un entero, pero representa un caracter,
        System.out.println(n); //imprime una A
        //si a una letra may�scula se le suma 32, se pasa a min�scula
        n += 32;
        System.out.println(n);
        //tambi�n puedo almacenar la variable con el caracter directamente
        n = 'f'; //el caracter asignado se debe encerrar entre comillas simples
        System.out.println(n);
        
        //String - NO ES UN TIPO DE DATO PRIMITIVO, ES UNA CLASE
        //representa una cadena de caracteres
        String o = "Hola"; //al ser una clase la primera letra va en may�scula
        //el valor asignado a una variable del tipo String debe ir entre ""
        String p = "Hola! soy una cadena de caracteres.";
        System.out.println(o);
        System.out.println(p);
        
        //algunos m�todos de la clase String:
        
        //.toLowerCase()
        //pasa la cadena a min�scula
        System.out.println(o.toLowerCase());
        
        //.toUpperCase()
        //pasa la cadena a may�scula
        System.out.println(p.toUpperCase());
        
        //concatenaci�n
        String nombre = "Marcelo";
        String apellido = "L�pez";
        System.out.println(nombre);
        System.out.println("El nombre es: " + nombre);
        System.out.println("Su nombre es: " + nombre + " y su apellido es: " + apellido);
        
    }
    
}
